package es.studium.Parchis;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

public class Modelo
{
	String driver = "com.mysql.cj.jdbc.Driver"; 
	String url = "jdbc:mysql://localhost:3306/juego"; 
	String login = "parchis"; // Usuario MySQL
	String password = "Studium2021;"; // Su clave correspondiente
	String sentencia = "SELECT nombreJugador, puntosJugador FROM jugadores ORDER BY 2 desc;";
	Connection connection = null; 
	Statement statement = null;
	Random rnd = new Random();
	ResultSet rs = null;

	public Modelo()
	{

	}

	public int tirada()
	{
		int t;
		t = rnd.nextInt(6)+1; // 0-5
		return (t);
	}

	public Connection conectar()
	{
		// Cargar el Driver
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			System.out.println("Se ha producido un error al cargar el Driver");
		}

		// Establecer la conexi�n con la base de datos
		try {
			connection = DriverManager.getConnection(url, login, password);
		} catch (SQLException e) {
			System.out.println("Se produjo un error al conectar a la Base de Datos");
		}
		return connection;
	}

	public String consultarRanking()
	{
		String contenido = "";
		ResultSet rs = null;
		// Realizar la consulta
		try {
			statement = connection.createStatement();
			rs = statement.executeQuery(sentencia);
			// Para averiguar el n�mero de registros obtenidos

			int i=0;

			//Para poder mostrar los 3 primeros
			while (rs.next() && (i<3)) {
				contenido = contenido+rs.getString("nombreJugador")+
						" --> "+rs.getInt("puntosJugador")+"\n";
				i++;
			}

		} catch (SQLException e) {
			System.out.println("Error en la sentencia SQL");
		}

		return contenido;
	}

	public void insertarJugador(String nombreJugador)
	{
		try {
			Connection conexion = conectar();
			PreparedStatement pt, update, insert;

			pt = conexion.prepareStatement("SELECT puntosJugador FROM jugadores WHERE nombreJugador = ?");
			update = conexion.prepareStatement("UPDATE jugadores SET puntosJugador = puntosJugador + 1 WHERE nombreJugador = ?");
			update.setString(1, nombreJugador);
			pt.setString(1, nombreJugador);

			//Si el ganador existe actualiza sus victorias sumando 1
			ResultSet rs = pt.executeQuery();
			if (rs.next() && rs.getInt(1) > 0) {
				update.executeUpdate();
				update.close();
			} else {
				//Recoge el �ltimo id para a�adir uno nuevo
				insert = conexion.prepareStatement("SELECT idJugador FROM jugadores ORDER BY idJugador DESC");
				rs = insert.executeQuery();
				insert = conexion.prepareStatement("INSERT INTO jugadores VALUES(?, ?, ?)");
				if (!rs.isBeforeFirst())
					insert.setInt(1, 1);
				else
				{
					rs.next();
					int id = rs.getInt(1)+1;
					insert.setInt(1, id);
				}

				insert.setString(2, nombreJugador);
				insert.setInt(3, 1);
				insert.executeUpdate();

				insert.close();
			}

			rs.close();
			pt.close();
			conexion.close();

		} catch (SQLException ex) {
			System.out.println("Error en la conexi�n de la base de datos");
			ex.printStackTrace();
		}

	}


	public void desconectar()
	{
		try
		{
			if(connection!=null)
			{
				connection.close();
			}
		}
		catch (SQLException e)
		{}
	}
}
