package es.studium.Parchis;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;

public class Controlador implements WindowListener, ActionListener, MouseListener
{
	VistaPrincipal vistaPrincipal;
	VistaTopTres vistaTopTres = new VistaTopTres(); // Top Tres
	NuevaPartida vistaPartidaNueva = new NuevaPartida(); // Nueva Partida
	Tablero tablero; // Tablero
	Modelo modelo;
	int numJugadores;
	int turno = 1;
	int numDado;
	int tiradas = 0;
	int distancia;
	Modelo md = new Modelo();

	public Controlador(Modelo m, VistaPrincipal v)
	{
		modelo = m;
		vistaPrincipal = v;
		vistaPrincipal.addWindowListener(this);
		vistaPrincipal.btnTopTres.addActionListener(this); // Top Tres
		vistaPrincipal.btnPartidaNueva.addActionListener(this); // Nueva Partida
		vistaPrincipal.btnAyuda.addActionListener(this); // Ayuda
		vistaPrincipal.btnSalir.addActionListener(this);
		vistaPartidaNueva.btnFIN.addActionListener(this);
		vistaTopTres.addWindowListener(this);
		vistaTopTres.btnVolver.addActionListener(this);
		vistaPartidaNueva.pedirNumeroJugadores.addWindowListener(this);
		vistaPartidaNueva.btnContinuar.addActionListener(this);
		vistaPartidaNueva.pedirNombresJugadores.addWindowListener(this);
		vistaPartidaNueva.btnComenzarPartida.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent ae)
	{
		Object botonPulsado = ae.getSource();
		if (botonPulsado.equals(vistaPrincipal.btnSalir) || botonPulsado.equals(vistaPartidaNueva.btnFIN))
		{
			System.exit(0);
		} else if (botonPulsado.equals(vistaPrincipal.btnTopTres)) // Top Tres
		{
			vistaTopTres.MostrarTopTres();
			vistaPrincipal.setVisible(false);
		} else if (botonPulsado.equals(vistaTopTres.btnVolver)) // Top Tres
		{
			vistaTopTres.OcultarTopTres();
			vistaPrincipal.setVisible(true);
		} else if (botonPulsado.equals(vistaPrincipal.btnPartidaNueva)) // Nueva Partida
		{
			vistaPartidaNueva.MostrarDialogNumeroJugadores();
			vistaPrincipal.setVisible(false);
		} 
		
		else if (botonPulsado.equals(vistaPrincipal.btnAyuda))
		{
			try
			{
				Runtime.getRuntime().exec("hh.exe AyudaParchis.chm");
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}

		else if (botonPulsado.equals(vistaPartidaNueva.btnContinuar)) // Nueva Partida
		{
			if (!vistaPartidaNueva.choNumeroJugadores.getSelectedItem().equals("Elegir n�mero de jugadores..."))
			{
				vistaPartidaNueva.PrepararDialogNombresJugadores(
						Integer.parseInt(vistaPartidaNueva.choNumeroJugadores.getSelectedItem()));
			}
		} else if (botonPulsado.equals(vistaPartidaNueva.btnComenzarPartida)) // Partida Nueva
		{
			
			numJugadores = Integer.parseInt(vistaPartidaNueva.choNumeroJugadores.getSelectedItem());
			if ((numJugadores == 4) && (!vistaPartidaNueva.txfNombre1.getText().equals(""))
					&& (!vistaPartidaNueva.txfNombre2.getText().equals(""))
					&& (!vistaPartidaNueva.txfNombre3.getText().equals(""))
					&& (!vistaPartidaNueva.txfNombre4.getText().equals("")))
			{
				tablero = new Tablero(4, vistaPartidaNueva.txfNombre1.getText(), vistaPartidaNueva.txfNombre2.getText(),
						vistaPartidaNueva.txfNombre3.getText(), vistaPartidaNueva.txfNombre4.getText());
				tablero.addWindowListener(this);
				tablero.addMouseListener(this);
				tablero.setVisible(true);
				vistaPartidaNueva.setVisible(false);
			} else if ((numJugadores == 3) && (!vistaPartidaNueva.txfNombre1.getText().equals(""))
					&& (!vistaPartidaNueva.txfNombre2.getText().equals(""))
					&& (!vistaPartidaNueva.txfNombre3.getText().equals("")))
			{
				tablero = new Tablero(3, vistaPartidaNueva.txfNombre1.getText(), vistaPartidaNueva.txfNombre2.getText(),
						vistaPartidaNueva.txfNombre3.getText(), "");
				tablero.addWindowListener(this);
				tablero.addMouseListener(this);
				tablero.setVisible(true);
				vistaPartidaNueva.setVisible(false);
			} else if ((numJugadores == 2) && (!vistaPartidaNueva.txfNombre1.getText().equals(""))
					&& (!vistaPartidaNueva.txfNombre2.getText().equals("")))
			{
				tablero = new Tablero(2, vistaPartidaNueva.txfNombre1.getText(), vistaPartidaNueva.txfNombre2.getText(),
						"", "");
				tablero.addWindowListener(this);
				tablero.addMouseListener(this);
				tablero.setVisible(true);
				vistaPartidaNueva.setVisible(false);
			} else
			{
				vistaPartidaNueva.txfNombre1.requestFocus();
			}
		}
	}

	@Override
	public void windowActivated(WindowEvent arg0)
	{
	}

	@Override
	public void windowClosed(WindowEvent arg0)
	{
	}

	@Override
	public void windowClosing(WindowEvent arg0)
	{
		if (vistaTopTres.isActive()) // Top Tres
		{
			vistaTopTres.OcultarTopTres();
			vistaPrincipal.setVisible(true);
		} else if (vistaPartidaNueva.pedirNumeroJugadores.isActive()) // Nueva Partida, pidiendo n�mero de jugadores
		{
			vistaPartidaNueva.pedirNumeroJugadores.removeWindowListener(this);
			vistaPartidaNueva.btnContinuar.removeActionListener(this);
			vistaPartidaNueva.OcultarDialogNumeroJugadores();
		} else if (vistaPartidaNueva.pedirNombresJugadores.isActive()) // Nueva Partida, pidiendo nombres jugadores
		{
			vistaPartidaNueva.pedirNombresJugadores.removeWindowListener(this);
			vistaPartidaNueva.btnComenzarPartida.removeActionListener(this);
			vistaPartidaNueva.choNumeroJugadores.select(0); // Reseteamos el desplegable
			vistaPartidaNueva.removeAll();
			vistaPartidaNueva.OcultarDialogNombresJugadores();
		} else if ((tablero != null) && (tablero.isActive())) // Tablero
		{
			tablero.removeWindowListener(this);
			tablero.removeMouseListener(this);
			tablero.setVisible(false);
			vistaPartidaNueva.OcultarDialogNombresJugadores();
			vistaPrincipal.setVisible(true);
			if (vistaPartidaNueva.mensajeGanador.isActive())
			{
				vistaPartidaNueva.mensajeGanador.removeWindowListener(this);
				vistaPartidaNueva.OcultarDialogFinPartida();
				vistaPrincipal.setVisible(false);
				vistaPartidaNueva.mensajeGanador.setVisible(true);
			}
		} else
		{
			System.exit(0);
		}
	}

	@Override
	public void windowDeactivated(WindowEvent arg0)
	{
	}

	@Override
	public void windowDeiconified(WindowEvent arg0)
	{
	}

	@Override
	public void windowIconified(WindowEvent arg0)
	{
	}

	@Override
	public void windowOpened(WindowEvent arg0)
	{
	}

	@Override
	public void mouseClicked(MouseEvent click)
	{
		int x = click.getX();
		int y = click.getY();
		// Pulsamos sobre el dado
		if ((x >= 33) && (x <= 73) && (y >= 217) && (y <= 277))
		{
			numDado = modelo.tirada();
			tiradas++;
			tablero.mostrarTirada(numDado);
			if (true)
			{
				// Actualizar la posici�n de la ficha
				for (int i = 0; i < numDado; i++)
				{

					switch (turno)
					{
					case 1:// COLOR ROJO
						if (tablero.xRojo > 360 && tablero.xRojo < 435 && tablero.yRojo > 10 && tablero.yRojo < 355)
						{

							tablero.yRojo += 41;

						} else if ((tablero.xRojo > 280 && tablero.xRojo < 360 && tablero.yRojo > 25
								&& tablero.yRojo < 350)
								|| (tablero.xRojo > 280 && tablero.xRojo < 330 && tablero.yRojo > 480
										&& tablero.yRojo < 780))
						{

							tablero.yRojo += 41;

						} else if ((tablero.xRojo > 0 && tablero.xRojo < 40 && tablero.yRojo > 310
								&& tablero.yRojo < 470))
						{

							tablero.yRojo += 65;

						} else if ((tablero.xRojo > 0 && tablero.xRojo < 280 && tablero.yRojo > 470
								&& tablero.yRojo < 570)
								|| (tablero.xRojo < 750 && tablero.xRojo > 440 && tablero.yRojo < 550
										&& tablero.yRojo > 470))
						{

							tablero.xRojo += 41;

						} else if (tablero.xRojo > 280 && tablero.xRojo < 430 && tablero.yRojo > 785
								&& tablero.yRojo < 825)
						{
							tablero.xRojo += 75;
						} else if ((tablero.yRojo < 820 && tablero.yRojo > 540 && tablero.xRojo > 430
								&& tablero.xRojo < 520)
								|| (tablero.yRojo > 65 && tablero.yRojo < 385 && tablero.xRojo > 440
										&& tablero.xRojo < 515))
						{

							tablero.yRojo -= 41;

						} else if ((tablero.yRojo > 340 && tablero.yRojo < 400 && tablero.xRojo < 350
								&& tablero.xRojo > 15)
								|| (tablero.yRojo > 300 && tablero.yRojo < 395 && tablero.xRojo > 520
										&& tablero.xRojo < 795))
						{

							tablero.xRojo -= 41;

						} else if ((tablero.yRojo > 385 & tablero.yRojo < 550 && tablero.xRojo > 755
								&& tablero.xRojo < 795))
						{
							tablero.yRojo -= 80;
						} else if (tablero.yRojo > 10 && tablero.yRojo < 65 && tablero.xRojo > 360
								&& tablero.xRojo < 515)
						{
							tablero.xRojo -= 90;
						} else
						{
							vistaPartidaNueva.FinPartida(vistaPartidaNueva.txfNombre1.getText());
                            modelo.insertarJugador(vistaPartidaNueva.txfNombre1.getText());
                            vistaPartidaNueva.MostrarDialogFinPartida();
						}
						
						break;

					case 2: // COLOR AMARILLO
						if (tablero.xAmarillo > 355 && tablero.xAmarillo < 440 && tablero.yAmarillo < 825
								&& tablero.yAmarillo > 500)
						{
							tablero.yAmarillo -= 41;

						} else if ((tablero.xAmarillo > 280 && tablero.xAmarillo < 360 && tablero.yAmarillo > 25
								&& tablero.yAmarillo < 350)
								|| (tablero.xAmarillo > 280 && tablero.xAmarillo < 330 && tablero.yAmarillo > 480
										&& tablero.yAmarillo < 780))
						{

							tablero.yAmarillo += 41;

						} else if ((tablero.xAmarillo > 0 && tablero.xAmarillo < 40 && tablero.yAmarillo > 310
								&& tablero.yAmarillo < 470))
						{

							tablero.yAmarillo += 65;

						} else if ((tablero.xAmarillo > 0 && tablero.xAmarillo < 280 && tablero.yAmarillo > 470
								&& tablero.yAmarillo < 570)
								|| (tablero.xAmarillo < 750 && tablero.xAmarillo > 440 && tablero.yAmarillo < 550
										&& tablero.yAmarillo > 470))
						{

							tablero.xAmarillo += 41;

						} else if (tablero.xAmarillo > 280 && tablero.xAmarillo < 430 && tablero.yAmarillo > 785
								&& tablero.yAmarillo < 825)
						{
							tablero.xAmarillo += 75;
						} else if ((tablero.yAmarillo < 820 && tablero.yAmarillo > 540 && tablero.xAmarillo > 430
								&& tablero.xAmarillo < 520)
								|| (tablero.yAmarillo > 65 && tablero.yAmarillo < 385 && tablero.xAmarillo > 440
										&& tablero.xAmarillo < 515))
						{

							tablero.yAmarillo -= 41;

						} else if ((tablero.yAmarillo > 340 && tablero.yAmarillo < 400 && tablero.xAmarillo < 350
								&& tablero.xAmarillo > 15)
								|| (tablero.yAmarillo > 300 && tablero.yAmarillo < 395 && tablero.xAmarillo > 520
										&& tablero.xAmarillo < 795))
						{

							tablero.xAmarillo -= 41;

						} else if ((tablero.yAmarillo > 385 & tablero.yAmarillo < 550 && tablero.xAmarillo > 755
								&& tablero.xAmarillo < 795))
						{
							tablero.yAmarillo -= 80;
						} else if (tablero.yAmarillo > 10 && tablero.yAmarillo < 65 && tablero.xAmarillo > 360
								&& tablero.xAmarillo < 515)
						{
							tablero.xAmarillo -= 90;
						} else
						{
							vistaPartidaNueva.FinPartida(vistaPartidaNueva.txfNombre2.getText());
                            modelo.insertarJugador(vistaPartidaNueva.txfNombre2.getText());
                            vistaPartidaNueva.MostrarDialogFinPartida();
						}

						break;

					case 3:// COLOR VERDE
						if (tablero.xVerde < 795 && tablero.xVerde > 470 && tablero.yVerde > 390
								&& tablero.yVerde < 465)
						{
							tablero.xVerde -= 41;
						} else if ((tablero.xVerde > 280 && tablero.xVerde < 360 && tablero.yVerde > 25
								&& tablero.yVerde < 350)
								|| (tablero.xVerde > 280 && tablero.xVerde < 330 && tablero.yVerde > 480
										&& tablero.yVerde < 780))
						{

							tablero.yVerde += 41;

						} else if ((tablero.xVerde > 0 && tablero.xVerde < 40 && tablero.yVerde > 310
								&& tablero.yVerde < 470))
						{

							tablero.yVerde += 65;

						} else if ((tablero.xVerde > 0 && tablero.xVerde < 280 && tablero.yVerde > 470
								&& tablero.yVerde < 570)
								|| (tablero.xVerde < 750 && tablero.xVerde > 440 && tablero.yVerde < 550
										&& tablero.yVerde > 470))
						{

							tablero.xVerde += 41;

						} else if (tablero.xVerde > 280 && tablero.xVerde < 430 && tablero.yVerde > 785
								&& tablero.yVerde < 825)
						{
							tablero.xVerde += 75;
						} else if ((tablero.yVerde < 820 && tablero.yVerde > 540 && tablero.xVerde > 430
								&& tablero.xVerde < 520)
								|| (tablero.yVerde > 65 && tablero.yVerde < 385 && tablero.xVerde > 440
										&& tablero.xVerde < 515))
						{

							tablero.yVerde -= 41;

						} else if ((tablero.yVerde > 340 && tablero.yVerde < 400 && tablero.xVerde < 350
								&& tablero.xVerde > 15)
								|| (tablero.yVerde > 300 && tablero.yVerde < 395 && tablero.xVerde > 520
										&& tablero.xVerde < 795))
						{

							tablero.xVerde -= 41;

						} else if ((tablero.yVerde > 385 & tablero.yVerde < 550 && tablero.xVerde > 755
								&& tablero.xVerde < 795))
						{
							tablero.yVerde -= 80;
						} else if (tablero.yVerde > 10 && tablero.yVerde < 65 && tablero.xVerde > 360
								&& tablero.xVerde < 515)
						{
							tablero.xVerde -= 90;
						} else
						{
							vistaPartidaNueva.FinPartida(vistaPartidaNueva.txfNombre3.getText());
                            modelo.insertarJugador(vistaPartidaNueva.txfNombre3.getText());
                            vistaPartidaNueva.MostrarDialogFinPartida();
						}

						break;

					case 4:// COLOR AZUL
						if (tablero.xAzul > 5 && tablero.xAzul < 320 && tablero.yAzul > 385 && tablero.yAzul < 470)
						{
							tablero.xAzul += 41;
						} else if ((tablero.xAzul > 280 && tablero.xAzul < 360 && tablero.yAzul > 25
								&& tablero.yAzul < 350)
								|| (tablero.xAzul > 280 && tablero.xAzul < 330 && tablero.yAzul > 480
										&& tablero.yAzul < 780))
						{

							tablero.yAzul += 41;

						} else if ((tablero.xAzul > 0 && tablero.xAzul < 40 && tablero.yAzul > 310
								&& tablero.yAzul < 470))
						{

							tablero.yAzul += 65;

						} else if ((tablero.xAzul > 0 && tablero.xAzul < 280 && tablero.yAzul > 470
								&& tablero.yAzul < 570)
								|| (tablero.xAzul < 750 && tablero.xAzul > 440 && tablero.yAzul < 550
										&& tablero.yAzul > 470))
						{

							tablero.xAzul += 41;

						} else if (tablero.xAzul > 280 && tablero.xAzul < 430 && tablero.yAzul > 785
								&& tablero.yAzul < 825)
						{
							tablero.xAzul += 75;
						} else if ((tablero.yAzul < 820 && tablero.yAzul > 540 && tablero.xAzul > 430
								&& tablero.xAzul < 520)
								|| (tablero.yAzul > 65 && tablero.yAzul < 385 && tablero.xAzul > 440
										&& tablero.xAzul < 515))
						{

							tablero.yAzul -= 41;

						} else if ((tablero.yAzul > 340 && tablero.yAzul < 400 && tablero.xAzul < 350
								&& tablero.xAzul > 15)
								|| (tablero.yAzul > 300 && tablero.yAzul < 395 && tablero.xAzul > 520
										&& tablero.xAzul < 795))
						{

							tablero.xAzul -= 41;

						} else if ((tablero.yAzul > 385 & tablero.yAzul < 550 && tablero.xAzul > 755
								&& tablero.xAzul < 795))
						{
							tablero.yAzul -= 80;
						} else if (tablero.yAzul > 10 && tablero.yAzul < 65 && tablero.xAzul > 360
								&& tablero.xAzul < 515)
						{
							tablero.xAzul -= 90;
						} else
						{
							vistaPartidaNueva.FinPartida(vistaPartidaNueva.txfNombre4.getText());
                            modelo.insertarJugador(vistaPartidaNueva.txfNombre4.getText());
                            vistaPartidaNueva.MostrarDialogFinPartida();
						}

						break;
					}
				}

				turno++;
				if (turno > numJugadores)
				{
					turno = 1;
				}
				tablero.actualizarTurno(turno);
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0)
	{
	}

	@Override
	public void mouseExited(MouseEvent arg0)
	{
	}

	@Override
	public void mousePressed(MouseEvent arg0)
	{
	}

	@Override
	public void mouseReleased(MouseEvent arg0)
	{
	}
}