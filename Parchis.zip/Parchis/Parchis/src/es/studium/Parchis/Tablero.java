package es.studium.Parchis;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

public class Tablero extends Frame
{
	private static final long serialVersionUID = 1L;
	Toolkit herramientas;
	Image tablero;
	int numJugadores;
	String jugador1, jugador2, jugador3, jugador4;
	int turnoJugador = 1;
	int tirada = 0;
	Font fuenteTirada = new Font("Algerian", Font.BOLD, 24);
	Font fuenteTurno = new Font("Algerian", Font.BOLD, 24);
	Font fuenteJugadores = new Font("Algerian", Font.BOLD, 22);

	int xRojo = 295, yRojo = 195;
	int xAmarillo = 490, yAmarillo = 640;
	int xVerde = 605, yVerde = 340;
	int xAzul = 170, yAzul = 510;

	public Tablero(int n, String j1, String j2, String j3, String j4)
	{
		numJugadores = n;
		jugador1 = j1;
		jugador2 = j2;
		jugador3 = j3;
		jugador4 = j4;
		herramientas = getToolkit();
		tablero = herramientas.getImage("tableroparchis.jpg");
		setTitle("Jugando a Parch�s Online"); // T�tulo
		setLayout(null); // Para poder posicionar los elementos en posiciones absolutas
		setSize(805, 835); // Tama�o de Frame
		setLocationRelativeTo(null); // Centrar la ventana
		setResizable(false); // Evitar redimensionado
	}

	public void paint(Graphics g)
	{
		g.drawImage(tablero, 0, 30, this);
		g.setFont(fuenteTirada);
		g.setColor(Color.black);
		g.drawString(" DADO", 55, 275);
		g.fillRect(50, 260, 10, 10);
		if (tirada != 0)
		{
			g.drawString(tirada + "", 53, 255);
		}
		g.setFont(fuenteTurno);
		// Turno
		switch (turnoJugador)
		{
		case 1:
			g.setColor(Color.red);
			g.drawString("Turno de", 10, 60);
			g.drawString(jugador1, 10, 90);

			break;
		case 2:
			g.setColor(Color.ORANGE);
			g.drawString("Turno de", 10, 60);
			g.drawString(jugador2, 10, 90);
			break;
		case 3:
			g.setColor(Color.green);
			g.drawString("Turno de", 10, 60);
			g.drawString(jugador3, 10, 90);
			break;
		case 4:
			g.setColor(Color.blue);
			g.drawString("Turno de", 10, 60);
			g.drawString(jugador4, 10, 90);
			break;
		}
		g.setFont(fuenteJugadores);
		// Jugadores
		g.setColor(Color.red);
		g.drawString(jugador1, 680, 60);
		g.fillOval(xRojo, yRojo, 15, 15); // Ficha Roja

		g.setColor(Color.orange);
		g.drawString(jugador2, 680, 90);
		g.fillOval(xAmarillo, yAmarillo, 15, 15); // Ficha Amarilla
		switch (numJugadores)
		{
		case 3:
			g.setColor(Color.green);
			g.drawString(jugador3, 680, 120);
			g.fillOval(xVerde, yVerde, 15, 15); // Ficha Verde
			break;
		case 4:
			g.setColor(Color.green);
			g.drawString(jugador3, 680, 120);
			g.fillOval(xVerde, yVerde, 15, 15);
			g.setColor(Color.blue);
			g.drawString(jugador4, 680, 150);
			g.fillOval(xAzul, yAzul, 15, 15); // Ficha Azul
			break;
		}
	}

	public void actualizarTurno(int t)
	{
		turnoJugador = t;
		repaint();
	}

	public void mostrarTirada(int t)
	{
		tirada = t;
		repaint();
	}

}