package es.studium.Parchis;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.TextArea;

public class VistaTopTres extends Frame
{
	private static final long serialVersionUID = 1L;
	TextArea txaRanking = new TextArea(20,10);
	Button btnVolver = new Button("Volver");
	Modelo md = new Modelo();
	
	public VistaTopTres()
	{
		md.conectar();
		setTitle("Parch�s Online: Ranking"); // T�tulo
		setBackground(Color.GREEN); // Color de fondo del Frame
		setLayout(new BorderLayout()); // Layout del Frame
		txaRanking.setText(md.consultarRanking());
		add(txaRanking, "Center");
		add(btnVolver, "South");
		setSize(420,220); // Tama�o de Frame
		setLocationRelativeTo(null); // Centrar la ventana
		setResizable(false); // Evitar redimensionado
		md.desconectar();
	}
	public void MostrarTopTres()
	{
		this.setVisible(true);
	}
	
	public void OcultarTopTres()
	{
		this.setVisible(false);
	}
}
